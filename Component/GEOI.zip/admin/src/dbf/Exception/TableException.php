<?php 

namespace XBase\Exception;

class TableException extends \RuntimeException
{
}